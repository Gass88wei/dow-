import os
import shutil
import subprocess
import sys
import threading
import asyncio
import tempfile
import re
import json  # 添加json模块导入
from io import BytesIO

from mutagen.mp3 import MP3
from docx import Document
import cv2
import numpy as np
import moviepy.editor as mp
from moviepy.audio.io.AudioFileClip import AudioFileClip
from moviepy.video.io.VideoFileClip import VideoFileClip
from moviepy.editor import CompositeAudioClip
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QLineEdit, QPushButton,
    QFileDialog, QCheckBox, QSlider, QTextEdit, QVBoxLayout, QHBoxLayout,
    QGroupBox, QScrollArea, QFrame, QSizePolicy, QMessageBox, QComboBox  # 添加 QComboBox
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QPixmap
from gradio_client import Client  # 导入 Gradio 客户端
from pydub import AudioSegment  # 用于处理音频


class Worker(QThread):
    update_progress = pyqtSignal(str)
    finished = pyqtSignal(bool)

    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window

    def run(self):
        try:
            self.main_window.generate_video()
            self.finished.emit(True)
        except Exception as e:
            self.update_progress.emit(f"错误: {str(e)}")
            self.finished.emit(False)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        # 初始化语音映射
        self.voice_mapping = {
            "zf_xiaobei": "晓北（标准女声）",
            "zf_xiaoni": "晓妮（甜美女声）",
            "zf_xiaoxiao": "晓晓（客服女声）",
            "zf_xiaoji": "晓姬（播音女声）",
            "zm_yunjian": "云间（成熟男声）",
            "zm_yunxi": "云溪（青年男声）",
            "zm_yunxia": "云夏（活力男声）",
            "zm_yungang": "云刚（浑厚男声）"
        }
        
        # 初始化 TTS 客户端
        try:
            # 设置gradio_client临时目录
            os.environ['GRADIO_TEMP_DIR'] = os.path.join(os.path.dirname(__file__), 'temp')
            temp_dir = os.environ['GRADIO_TEMP_DIR']
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)
            
            self.tts_client = Client("http://localhost:7860/")  # 本地 Gradio 服务器
            print("成功初始化Gradio客户端")
        except Exception as e:
            print(f"初始化Gradio客户端失败: {str(e)}")
            QMessageBox.critical(self, "错误", f"无法连接到Gradio服务器: {str(e)}")
            self.tts_client = None
        
        # 加载用户设置
        self.settings_file = os.path.join(os.path.dirname(__file__), "user_settings.json")
        self.load_settings()
        

        # 设置 UI
        self.setup_ui()
        self.setWindowTitle("文档转视频生成工具 v1.0")
        self.resize(1000, 800)

    def setup_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout(main_widget)

        # 左侧布局
        left_layout = QVBoxLayout()

        # 文件选择部分
        self.word_doc_entry = QLineEdit()
        self.bg_audio_entry = QLineEdit()
        self.export_dir_entry = QLineEdit()
        
        # 应用已保存的导出目录
        if hasattr(self, 'last_export_dir') and self.last_export_dir:
            self.export_dir_entry.setText(self.last_export_dir)

        file_group = QGroupBox("文件设置")
        file_layout = QVBoxLayout()
        file_layout.addWidget(self.create_file_selector("Word文档", self.word_doc_entry, "*.docx"))
        file_layout.addWidget(self.create_file_selector("背景音乐", self.bg_audio_entry, "*.mp3;*.wav"))
        file_layout.addWidget(self.create_dir_selector("导出目录", self.export_dir_entry))
        file_group.setLayout(file_layout)
        left_layout.addWidget(file_group)

        # 语音选择
        self.voice_combo = QComboBox()
        for voice_id, name in self.voice_mapping.items():  # 使用 self.voice_mapping
            self.voice_combo.addItem(name, voice_id)
        # 应用已保存的语音设置
        if hasattr(self, 'last_voice') and self.last_voice:
            index = self.voice_combo.findData(self.last_voice)
            if index >= 0:
                self.voice_combo.setCurrentIndex(index)
            else:
                self.voice_combo.setCurrentIndex(0)
        else:
            self.voice_combo.setCurrentIndex(0)
        left_layout.addWidget(QLabel("选择语音："))
        left_layout.addWidget(self.voice_combo)

        # 音量控制
        volume_group = QGroupBox("音量控制")
        volume_layout = QVBoxLayout()
        self.bg_volume = QSlider(Qt.Horizontal)
        self.bg_volume.setRange(0, 100)
        self.bg_volume.setValue(self.last_bg_volume if hasattr(self, 'last_bg_volume') else 50)
        volume_layout.addWidget(self.create_slider("背景音乐音量", self.bg_volume))

        self.voice_volume = QSlider(Qt.Horizontal)
        self.voice_volume.setRange(0, 100)
        self.voice_volume.setValue(self.last_voice_volume if hasattr(self, 'last_voice_volume') else 100)
        volume_layout.addWidget(self.create_slider("配音音量", self.voice_volume))
        volume_group.setLayout(volume_layout)
        left_layout.addWidget(volume_group)

        # 字幕设置
        self.subtitle_check = QCheckBox("启用字幕")
        self.subtitle_check.setChecked(True)
        left_layout.addWidget(self.subtitle_check)

        # 进度显示
        self.progress_text = QTextEdit()
        self.progress_text.setReadOnly(True)
        scroll = QScrollArea()
        scroll.setWidget(self.progress_text)
        scroll.setWidgetResizable(True)
        left_layout.addWidget(scroll)

        # 操作按钮
        btn_layout = QHBoxLayout()
        self.start_btn = QPushButton("开始生成")
        self.start_btn.clicked.connect(self.start_generation)
        self.view_btn = QPushButton("打开目录")
        self.view_btn.clicked.connect(self.open_export_dir)
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.view_btn)
        left_layout.addLayout(btn_layout)

        # 右侧布局（已移除无用内容）
        right_layout = QVBoxLayout()
        right_layout.addStretch()  # 仅保留一个占位符，保持布局平衡

        main_layout.addLayout(left_layout, 100)  # 左侧占满整个窗口
        main_layout.addLayout(right_layout, 0)   # 右侧不占用空间

    def create_file_selector(self, label, entry, file_type):
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.addWidget(QLabel(label))
        layout.addWidget(entry)
        btn = QPushButton("浏览")
        btn.clicked.connect(lambda: self.choose_file(entry, file_type))
        layout.addWidget(btn)
        return widget

    def create_dir_selector(self, label, entry):
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.addWidget(QLabel(label))
        layout.addWidget(entry)
        btn = QPushButton("浏览")
        btn.clicked.connect(lambda: self.choose_dir(entry))
        layout.addWidget(btn)
        return widget

    def create_slider(self, label, slider):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(QLabel(label))
        layout.addWidget(slider)
        return widget

    def choose_file(self, entry, file_type):
        path, _ = QFileDialog.getOpenFileName(self, "选择文件", "", f"文件 ({file_type})")
        if path:
            entry.setText(path)

    def choose_dir(self, entry):
        path = QFileDialog.getExistingDirectory(self, "选择目录")
        if path:
            entry.setText(path)

    def start_generation(self):
        # 检查必要的输入
        if not self.word_doc_entry.text():
            QMessageBox.critical(self, "错误", "请选择 Word 文档")
            return
        if not self.export_dir_entry.text():
            QMessageBox.critical(self, "错误", "请选择导出目录")
            return
            
        self.worker = Worker(self)
        self.worker.update_progress.connect(self.update_progress)
        self.worker.finished.connect(self.task_finished)
        self.worker.start()

    def update_progress(self, text):
        self.progress_text.append(text)

    def task_finished(self, success):
        if success:
            # 保存当前设置
            self.save_settings()
            QMessageBox.information(self, "完成", "视频生成成功！")
        else:
            QMessageBox.critical(self, "错误", "生成过程中发生错误！")

    def generate_video(self):
        # 获取用户输入
        word_doc_path = self.word_doc_entry.text()
        export_dir = self.export_dir_entry.text()
        bg_audio_path = self.bg_audio_entry.text()
        bg_volume = self.bg_volume.value() / 100
        voice_volume = self.voice_volume.value() / 100
        enable_subtitles = self.subtitle_check.isChecked()

        if not word_doc_path:
            QMessageBox.critical(self, "错误", "请选择 Word 文档")
            return
        if not export_dir:
            QMessageBox.critical(self, "错误", "请选择导出目录")
            return

        self.progress_text.append("开始任务...")
        try:
            # 提取图片和文字
            images, texts, temp_dir = self.get_images_and_texts(word_doc_path)
            if not images or not texts:
                self.progress_text.append("错误: Word 文档中没有找到图片或文字")
                return

            # 生成 TTS 音频
            audio_files = []
            for idx, text in enumerate(texts):
                audio_file = os.path.join(export_dir, f"audio_{idx}.wav")
                self.generate_tts_audio(text, audio_file)
                audio_files.append(audio_file)
                self.progress_text.append(f"生成配音：{text[:30]}...")

            # 生成视频
            output_file = os.path.join(export_dir, "output_video.mp4")
            self.generate_video_with_audio(images, texts, audio_files, output_file, bg_audio_path, bg_volume, voice_volume, enable_subtitles)
            self.progress_text.append("视频生成完成！")
        except Exception as e:
            self.progress_text.append(f"错误: {str(e)}")

    def get_images_and_texts(self, docx_path):
        """从Word文档中提取图片和文字"""
        temp_dir = tempfile.mkdtemp()
        doc = Document(docx_path)
        images = []
        texts = []

        for i, para in enumerate(doc.paragraphs):
            if para.text.strip():
                texts.append(para.text.strip())

        for rel in doc.part.rels.values():
            if "image" in rel.target_ref:
                image_path = os.path.join(temp_dir, os.path.basename(rel.target_ref))
                with open(image_path, 'wb') as f:
                    f.write(rel.target_part.blob)
                images.append(image_path)

        return images, texts, temp_dir
        try:
            doc = Document(doc_path)
            images = []
            texts = []
            temp_dir = tempfile.mkdtemp()

            for i, para in enumerate(doc.paragraphs):
                text = para.text.strip()
                if text:
                    texts.append(text)
                    # 为每段文本创建一个默认的白色背景图片
                    img = np.ones((720, 1280, 3), dtype=np.uint8) * 255
                    img_path = os.path.join(temp_dir, f"slide_{i}.jpg")
                    cv2.imwrite(img_path, img)
                    images.append(img_path)

            # 处理文档中的图片
            for i, rel in enumerate(doc.part.rels.values()):
                if "image" in rel.target_ref:
                    # 将图片数据保存到临时文件
                    img_data = rel.target_part.blob
                    img_path = os.path.join(temp_dir, f"doc_image_{i}.jpg")
                    with open(img_path, "wb") as f:
                        f.write(img_data)
                    images.append(img_path)
                    texts.append("")  # 为图片添加空文本

            return images, texts, temp_dir
        except Exception as e:
            raise Exception(f"提取图片和文本失败: {str(e)}")

    def convert_digits_to_chinese(self, text):
        """将数字转换为中文读法"""
        def convert_number(match):
            num = match.group(0)
            try:
                if num.isdigit():
                    n = int(num)
                    if n == 0:
                        return '零'
                    
                    units = ['', '十', '百', '千', '万', '十', '百', '千', '亿', '十', '百', '千', '兆']
                    chars = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九']
                    
                    chinese = ''
                    unit_pos = 0
                    while n > 0:
                        digit = n % 10
                        if digit != 0:
                            chinese = chars[digit] + units[unit_pos] + chinese
                        elif chinese and chinese[0] != '零':
                            chinese = '零' + chinese
                        n //= 10
                        unit_pos += 1
                    
                    if chinese.startswith('一十'):
                        chinese = chinese[1:]
                    
                    return chinese
                return num
            except Exception as e:
                return num
        
        pattern = r'\d+'
        return re.sub(pattern, convert_number, text)

    def generate_tts_audio(self, text, output_file):
        """使用 TTS 生成音频"""
        try:
            # 将数字转换为中文读法
            processed_text = self.convert_digits_to_chinese(text)
            result = self.tts_client.predict(
                text=processed_text,
                voice=self.voice_combo.currentData(),
                speed=1.0,  # 语速
                api_name="/generate_speech"
            )
            audio_path = result[1]
            # 使用pydub确保音频格式转换为WAV
            audio = AudioSegment.from_file(audio_path)
            audio.export(output_file, format="wav")
        except Exception as e:
            raise Exception(f"TTS 生成失败: {str(e)}")

    def generate_video_with_audio(self, images, texts, audio_files, output_file, bg_audio_path, bg_volume, voice_volume, enable_subtitles):
        """生成视频并合并音频"""
        try:
            clips = []
            total_duration = 0
            max_length = max(len(images), len(audio_files))
            
            for idx in range(max_length):
                # 获取音频时长
                audio_duration = 0
                if idx < len(audio_files):
                    audio_path = audio_files[idx]
                    audio_duration = self.get_audio_duration(audio_path)
                    if not audio_duration:
                        audio_duration = 5  # 如果获取失败，使用默认时长
                else:
                    audio_duration = 5  # 如果没有对应的音频，使用默认时长
                
                # 获取图片
                if idx < len(images):
                    image_path = images[idx]
                else:
                    # 如果图片不够，使用最后一张图片
                    image_path = images[-1] if images else None
                
                if not image_path:
                    continue
                
                # 创建视频片段
                clip = mp.ImageClip(image_path).set_duration(audio_duration)
                
                # 添加音频
                if idx < len(audio_files):
                    # 使用复制流处理WAV音频
                    audio_clip = AudioFileClip(audio_files[idx], buffersize=200000)
                    if voice_volume != 1.0:
                        audio_clip = audio_clip.volumex(voice_volume)
                    clip = clip.set_audio(audio_clip)
                
                # 添加过渡效果
                if idx > 0:
                    clip = clip.crossfadein(1)
                    previous_clip = clips[-1]
                    previous_clip = previous_clip.crossfadeout(1)
                    clips[-1] = previous_clip
                
                clips.append(clip)
                total_duration += audio_duration
            
            if not clips:
                raise Exception("没有有效的视频片段可以生成")
            
            final_clip = mp.concatenate_videoclips(clips, method="compose")
            
            # 如果有背景音乐，合并音频
            if bg_audio_path and os.path.exists(bg_audio_path):
                bg_audio = AudioFileClip(bg_audio_path, buffersize=200000)
                if bg_volume != 1.0:
                    bg_audio = bg_audio.volumex(bg_volume)
                # 确保背景音乐长度与视频相同
                if bg_audio.duration < final_clip.duration:
                    bg_audio = bg_audio.loop(duration=final_clip.duration)
                else:
                    bg_audio = bg_audio.subclip(0, final_clip.duration)
                final_audio = CompositeAudioClip([final_clip.audio, bg_audio])
                final_clip = final_clip.set_audio(final_audio)
            
            # 生成视频，使用复制流处理音频
            if os.path.exists(output_file):
                os.remove(output_file)
            final_clip.write_videofile(output_file, fps=24, codec="libx264", 
                                     audio_codec="pcm_s16le", # 使用WAV格式
                                     preset="faster", threads=4,
                                     write_logfile=False)
            
            # 嵌入字幕（如果需要）
            if enable_subtitles:
                srt_file_path = os.path.join(os.path.dirname(output_file), "subtitles.srt")
                self.generate_srt_file(texts, total_duration, output_file)
                self.embed_subtitles(output_file, srt_file_path)
        
        except Exception as e:
            raise Exception(f"视频生成失败: {str(e)}")

    def generate_srt_file(self, texts, total_duration, output_file):
        """生成 SRT 字幕文件，根据音频时长计算每个字幕的显示时间"""
        try:
            srt_file_path = os.path.join(os.path.dirname(output_file), "subtitles.srt")
            with open(srt_file_path, "w", encoding="utf-8") as f:
                current_time = 0
                for idx, text in enumerate(texts, 1):
                    # 获取对应音频的时长
                    audio_file = os.path.join(os.path.dirname(output_file), f"audio_{idx-1}.wav")
                    duration = self.get_audio_duration(audio_file) if os.path.exists(audio_file) else 5
                    
                    start_time = self.format_timestamp(current_time)
                    end_time = self.format_timestamp(current_time + duration)
                    
                    # 确保字幕格式正确，移除可能的特殊字符
                    clean_text = text.strip().replace('\n', ' ')
                    f.write(f"{idx}\n{start_time} --> {end_time}\n{clean_text}\n\n")
                    
                    current_time += duration
        except Exception as e:
            raise Exception(f"生成字幕文件失败: {str(e)}")

    def embed_subtitles(self, video_file, srt_file_path):
        """嵌入字幕到视频"""
        try:
            # 规范化路径，确保路径格式正确
            video_file = os.path.abspath(video_file)
            srt_file_path = os.path.abspath(srt_file_path)
            output_file = os.path.abspath(os.path.join(
                os.path.dirname(video_file),
                os.path.splitext(os.path.basename(video_file))[0] + '_with_subtitles.mp4'
            ))
            
            # 拷贝字幕文件到临时目录
            temp_srt = os.path.join(os.path.dirname(video_file), "temp.srt")
            shutil.copy(srt_file_path, temp_srt)
            
            # 构建ffmpeg命令
            cmd = f'ffmpeg -i "{video_file}" -vf "subtitles=temp.srt:force_style=\'FontName=Arial,Fontsize=24,PrimaryColour=&HFFFFFF,OutlineColour=&H000000,BorderStyle=1,Outline=2,Alignment=2\'" -c:a copy -y "{output_file}"'
            
            # 执行命令
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=os.path.dirname(video_file))
            if result.returncode != 0:
                raise Exception(f"FFmpeg错误: {result.stderr}")
            
            # 清理并替换文件
            os.remove(temp_srt)
            if os.path.exists(output_file):
                os.replace(output_file, video_file)
                
        except subprocess.CalledProcessError as e:
            raise Exception(f"嵌入字幕失败: {e.stderr if hasattr(e, 'stderr') else str(e)}")
        except Exception as e:
            raise Exception(f"嵌入字幕失败: {str(e)}")

    def format_timestamp(self, seconds):
        """将秒数转换为 SRT 时间格式"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        seconds_remainder = seconds % 60
        return f"{hours:02d}:{minutes:02d}:{seconds_remainder:06.3f}".replace('.', ',')

    def get_audio_duration(self, audio_file):
        """获取音频时长"""
        try:
            audio = AudioSegment.from_file(audio_file)
            return len(audio) / 1000.0  # 将毫秒转换为秒
        except Exception as e:
            try:
                audio = MP3(audio_file)
                return audio.info.length
            except Exception as e:
                raise Exception(f"获取音频时长失败: {str(e)}")

    def open_export_dir(self):
        export_dir = self.export_dir_entry.text()
        if not export_dir:
            QMessageBox.critical(self, "错误", "请选择导出目录")
            return
        os.startfile(export_dir)
        
    def load_settings(self):
        """加载用户设置"""
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    settings = json.loads(f.read())
                    self.last_voice = settings.get('voice', '')
                    self.last_bg_volume = settings.get('bg_volume', 50)
                    self.last_voice_volume = settings.get('voice_volume', 100)
                    self.last_export_dir = settings.get('export_dir', '')
        except Exception as e:
            print(f"加载设置失败: {str(e)}")
            
    def save_settings(self):
        """保存用户设置"""
        try:
            settings = {
                'voice': self.voice_combo.currentData(),
                'bg_volume': self.bg_volume.value(),
                'voice_volume': self.voice_volume.value(),
                'export_dir': self.export_dir_entry.text()
            }
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(settings, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存设置失败: {str(e)}")
            
    def process_next_doc(self):
        """处理队列中的下一个文档"""
        if self.doc_queue:
            next_doc = self.doc_queue.pop(0)
            self.word_doc_entry.setText(next_doc)
            self.worker = Worker(self)
            self.worker.update_progress.connect(self.update_progress)
            self.worker.finished.connect(self.task_finished)
            self.worker.start()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())